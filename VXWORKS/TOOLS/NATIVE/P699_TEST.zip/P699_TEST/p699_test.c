/*********************  P r o g r a m  -  M o d u l e ***********************/
/*
 *        \file  p699_test.c
 *
 *      \author  ts
 *        $Date: $
 *    $Revision: $
 *
 *  	\brief	P699 DMA Test Tool
 *           	
 *
 *---------------------------[ History ] --------------------------------------
 *
 * $Log: $
 *
 *****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

#include "vxWorks.h"
#include "version.h"
#include "stdlib.h"
#include "cacheLib.h"
#include "intLib.h"
#include "stdio.h"
#include "sysLib.h"
#include "errno.h"
#include "errnoLib.h"
#include "memLib.h"

#include <MEN/men_typs.h>
#include <MEN/maccess.h>
#include <MEN/men_typs.h>
#include <MEN/mdis_api.h>
#include <MEN/oss.h>
#include <MEN/usr_oss.h>
#include <MEN/usr_utl.h>



/*--------------------------------------+
|   PROTOTYPES                          |
+--------------------------------------*/

static void usage(void);


/*--------------------------------------+
|   DEFINES                             |
+--------------------------------------*/

#define CHK(expression) \
 if((expression)) {\
	 printf("*** Error during: %s\nfile %s\nline %d\n", \
     #expression,__FILE__,__LINE__);\
     goto ABORT;\
 }

#define PCI_SEEK_VENDOR		0x1172
#define PCI_SEEK_DEVICE		0x4d45



/*------------------+
|   GLOBALS         |
+------------------*/

/* none */

/********************************* usage ***********************************/
/**  Print program usage
 */
static void usage(void)
{
	printf("Usage: p699_test [-i=irq][-s=size] [-d] \n");
	printf(" Tool to perform P699 DMA Tests\n");
	printf("Options: \n");
	printf(" -s=<size>    transfer size,  in 32bit longs\n");
	printf(" -i=<irq>     Interrupt Vector (/PCIA .. /PCID)\n");
	printf(" -d           dump Z062 Registers\n");
	printf("\n(c) 2007 by MEN mikro elektronik GmbH\n\n");
}


/***************************************************************************/
/**  helper to free a pointer if previously allocated by malloc
 *
 *  \param mem      \IN malloced pointer to free or NULL
 *
 *  \return	        -
 */
static void do_free(void *mem )
{
	if (mem)
		free(mem);
}


#if 1

/*  PCI command bits  */

#define PCI_CMD_IO_ENABLE		0x0001	/* IO access enable */
#define PCI_CMD_MEM_ENABLE		0x0002	/* memory access enable */
#define PCI_CMD_MASTER_ENABLE	0x0004	/* bus master enable */
#define PCI_CMD_MON_ENABLE		0x0008	/* monitor special cycles enable */
#define PCI_CMD_WI_ENABLE		0x0010	/* write and invalidate enable */
#define PCI_CMD_SNOOP_ENABLE	0x0020	/* palette snoop enable */
#define PCI_CMD_PERR_ENABLE		0x0040	/* parity error enable */
#define PCI_CMD_WC_ENABLE		0x0080	/* wait cycle enable */
#define PCI_CMD_SERR_ENABLE		0x0100	/* system error enable */
#define PCI_CMD_FBTB_ENABLE		0x0200	/* fast back to back enable */

/* PCI base address mask bits */

#define PCI_MEMBASE_MASK	~0xf	/* mask for memory base address */
#define PCI_IOBASE_MASK		~0x3	/* mask for IO base address */
#define PCI_BASE_IO			0x1	/* IO space indicator */
#define PCI_BASE_BELOW_1M	0x2	/* memory locate below 1MB */
#define PCI_BASE_IN_64BITS	0x4	/* memory locate anywhere in 64 bits */
#define PCI_BASE_PREFETCH	0x8	/* memory prefetchable */

/* PCI header type bits */

#define PCI_HEADER_TYPE_MASK	0x7f	/* mask for header type */
#define PCI_HEADER_PCI_PCI		0x01	/* PCI to PCI bridge */
#define PCI_HEADER_MULTI_FUNC	0x80	/* multi function device */

/* * Standard device configuration register offsets * */
/* * Note that only modulo-4 addresses are written to the address register * */

#define	PCI_CFG_VENDOR_ID		0x00
#define	PCI_CFG_DEVICE_ID		0x02
#define	PCI_CFG_COMMAND			0x04
#define	PCI_CFG_STATUS			0x06
#define	PCI_CFG_REVISION		0x08
#define	PCI_CFG_PROGRAMMING_IF	0x09
#define	PCI_CFG_SUBCLASS		0x0a
#define	PCI_CFG_CLASS			0x0b
#define	PCI_CFG_CACHE_LINE_SIZE	0x0c
#define	PCI_CFG_LATENCY_TIMER	0x0d
#define	PCI_CFG_HEADER_TYPE		0x0e
#define	PCI_CFG_BIST			0x0f
#define	PCI_CFG_BASE_ADDRESS_0	0x10
#define	PCI_CFG_BASE_ADDRESS_1	0x14
#define	PCI_CFG_BASE_ADDRESS_2	0x18
#define	PCI_CFG_BASE_ADDRESS_3	0x1c
#define	PCI_CFG_BASE_ADDRESS_4	0x20
#define	PCI_CFG_BASE_ADDRESS_5	0x24
#define	PCI_CFG_CIS				0x28
#define	PCI_CFG_SUB_VENDER_ID	0x2c
#define	PCI_CFG_SUB_SYSTEM_ID	0x2e
#define	PCI_CFG_EXPANSION_ROM	0x30
#define	PCI_CFG_RESERVED_0		0x34
#define	PCI_CFG_RESERVED_1		0x38
#define	PCI_CFG_DEV_INT_LINE	0x3c
#define	PCI_CFG_DEV_INT_PIN		0x3d
#define	PCI_CFG_MIN_GRANT		0x3e
#define	PCI_CFG_MAX_LATENCY		0x3f

/* * PCI-to-PCI bridge configuration register offsets * */
/* * Note that only modulo-4 addresses are written to the address register * */

#define	PCI_CFG_PRIMARY_BUS			0x18
#define	PCI_CFG_SECONDARY_BUS		0x19
#define	PCI_CFG_SUBORDINATE_BUS		0x1a
#define	PCI_CFG_SEC_LATENCY			0x1b
#define	PCI_CFG_IO_BASE				0x1c
#define	PCI_CFG_IO_LIMIT			0x1d
#define	PCI_CFG_SEC_STATUS			0x1e
#define	PCI_CFG_MEM_BASE			0x20
#define	PCI_CFG_MEM_LIMIT			0x22
#define	PCI_CFG_PRE_MEM_BASE		0x24
#define	PCI_CFG_PRE_MEM_LIMIT		0x26
#define	PCI_CFG_PRE_MEM_BASE_U		0x28
#define	PCI_CFG_PRE_MEM_LIMIT_U		0x2c
#define	PCI_CFG_IO_BASE_U			0x30
#define	PCI_CFG_IO_LIMIT_U			0x32
#define	PCI_CFG_ROM_BASE			0x38
#define	PCI_CFG_BRG_INT_LINE		0x3c
#define	PCI_CFG_BRG_INT_PIN			0x3d
#define	PCI_CFG_BRIDGE_CONTROL		0x3e


#endif

/***************************************************************************/
/** Program main function
 *
 *  \param argc       \IN  argument counter
 *  \param argv       \IN  argument vector
 *
 *  \return	          success (0) or error (1)
 */
int main(int argc, char *argv[])
{
	char	 	buf[40], *errstr = NULL, *str;
	u_int32  	*txbufP = NULL, *rxbufP = NULL;
	int32	 	dump=0, size=0, irqVector=0;
	int32 		i=0;
	STATUS		retval=0;
	int 		pciVendor	= PCI_SEEK_VENDOR;
	int 		pciDevice	= PCI_SEEK_DEVICE;
	int 		pciBus		= 0;
	int 		pciDev		= 0;
	int 		pciFunc		= 0;

	u_int32  	bar0P = 0;
	u_int32  	bar1P = 0;
	u_int32  	data = 0;


	printf("MEN P699 DMA test tool built %s %s\n", __DATE__, __TIME__ );

	/*----------------------+
    |  check arguments      |
    +----------------------*/
	if( (errstr = UTL_ILLIOPT("ds=i=", buf)) ){
		printf("*** %s\n", errstr);
		return(1);
	}

	if( argc < 2 ){
		usage();
		return(1);
	}

	dump 		= (UTL_TSTOPT("d") ? 1 : 0);
	size 		= ((str = UTL_TSTOPT("s=")) ? atoi(str) : 128);
	irqVector 	= ((str = UTL_TSTOPT("i=")) ? atoi(str) : 0);

	/* 1. Allocate & clean a 1k aligned Tx Rx Buffer */
	CHK( (rxbufP =(u_int32*)memalign( 0x1000, size * sizeof(u_int32)))==NULL);
	CHK( (txbufP =(u_int32*)memalign( 0x1000, size * sizeof(u_int32)))==NULL);
	memset(rxbufP, 0x00, size * sizeof(u_int32) );
	memset(txbufP, 0x00, size * sizeof(u_int32) );

	printf("Allocated Buffers:\n");
	printf("TX buf 0x%08x\n", txbufP );
	printf("RX buf 0x%08x\n", rxbufP );


	/* 2. Find the P599 FPGA (PCI Core) */
	printf("Seek PCI Device 0x%04x / 0x%04x : ", pciVendor, pciDevice);	

	retval = pciFindDevice(pciVendor, pciDevice,0, &pciBus, &pciDev, &pciFunc);
	if (retval == OK) {
		printf("OK. Bus: %d Dev: %d Func: %d\n", pciBus, pciDev, pciFunc);
	} else {
		printf("*** not found!\n");
		return(ERROR);
	}

	OSS_PciGetConfig(NULL, pciBus, pciDev, pciFunc, OSS_PCI_ADDR_0, &bar0P) ;
	OSS_PciGetConfig(NULL, pciBus, pciDev, pciFunc, OSS_PCI_ADDR_1, &bar1P) ;
	printf("BAR0: 0x%08x\n", bar0P);
	printf("BAR1: 0x%08x\n", bar1P);

	/* display memory */
	for (i = 0; i < 0x10; i++ ) {
		data = MREAD_D8(bar0P, i);
		printf("%02x ", data);
	}

	/*--------------------+
    |  cleanup            |
    +--------------------*/
	do_free(txbufP);
	do_free(rxbufP);
	return(0);

ABORT:

	do_free(txbufP);
	do_free(rxbufP);
	return(UOS_ErrnoGet());
}



/* 	/\* 3. Get Addresses for DMA BDs *\/ */
/* 	retval = pciConfigInLong(pciBus, pciDev, pciFunc, PCI_CFG_BASE_ADDRESS_0, */
/* 							 bar0P ); */

/* 	printf("BAR0: 0x%08x\n", *bar0P); */

/* 	/\* 3. Get Addresses for DMA BDs *\/ */
/* 	retval = pciConfigInLong(pciBus, pciDev, pciFunc,  */
/* 							 PCI_CFG_BASE_ADDRESS_1, */
/* 							 bar1P ); */

/* 	printf("BAR1: 0x%08x\n", *bar1P); */

/* 	retval = pciFindDevice(pciVendor, */
/* 						   pciDevice, */
/* 						   0,	/\* index *\/ */
/* 						   &pciBus, */
/* 						   &pciDev, */
/* 						   &pciFunc	); */

     
/* OSS_PCI_VENDOR_ID  */
/* OSS_PCI_DEVICE_ID  */
/* OSS_PCI_COMMAND  */
/* OSS_PCI_STATUS  */
/* OSS_PCI_REVISION_ID  */
/* OSS_PCI_CLASS  */
/* OSS_PCI_SUB_CLASS  */
/* OSS_PCI_PROG_IF  */
/* OSS_PCI_CACHE_LINE_SIZE  */
/* OSS_PCI_PCI_LATENCY_TIMER  */
/* OSS_PCI_HEADER_TYPE  */
/* OSS_PCI_BIST  */
/* OSS_PCI_ADDR_0  */
/* OSS_PCI_ADDR_1  */
/* OSS_PCI_ADDR_2  */
/* OSS_PCI_ADDR_3  */
/* OSS_PCI_ADDR_4  */
/* OSS_PCI_ADDR_5  */
/* OSS_PCI_CIS  */
/* OSS_PCI_SUBSYS_VENDOR_ID  */
/* OSS_PCI_SUBSYS_ID  */
/* OSS_PCI_EXPROM_ADDR  */
/* OSS_PCI_INTERRUPT_PIN  */
/* OSS_PCI_INTERRUPT_LINE */
